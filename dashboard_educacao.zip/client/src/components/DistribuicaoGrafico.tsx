import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface DistribuicaoGraficoProps {
  data: Array<{
    faixa: string;
    matematica: number;
    redacao: number;
  }>;
}

export function DistribuicaoGrafico({ data }: DistribuicaoGraficoProps) {
  return (
    <div className="w-full h-full bg-white rounded-lg p-6 shadow-sm border border-gray-200">
      <div className="mb-6">
        <h3 className="text-xl font-bold text-gray-900 font-playfair">
          Distribuição de Notas
        </h3>
        <p className="text-sm text-gray-600 mt-1">
          Quantidade de alunos por faixa de nota em Matemática e Redação
        </p>
      </div>

      <ResponsiveContainer width="100%" height={400}>
        <BarChart data={data} margin={{ top: 20, right: 30, left: 0, bottom: 20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis
            dataKey="faixa"
            tick={{ fill: "#6b7280", fontSize: 12 }}
            axisLine={{ stroke: "#d1d5db" }}
          />
          <YAxis
            tick={{ fill: "#6b7280", fontSize: 12 }}
            axisLine={{ stroke: "#d1d5db" }}
            label={{ value: "Quantidade de Alunos", angle: -90, position: "insideLeft" }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "#fff",
              border: "1px solid #e5e7eb",
              borderRadius: "0.5rem",
            }}
            formatter={(value) => [value, ""]}
          />
          <Legend
            wrapperStyle={{ paddingTop: "1.5rem" }}
            iconType="square"
          />
          <Bar
            dataKey="matematica"
            fill="#1e40af"
            name="Matemática"
            radius={[4, 4, 0, 0]}
          />
          <Bar
            dataKey="redacao"
            fill="#3b82f6"
            name="Redação"
            radius={[4, 4, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
