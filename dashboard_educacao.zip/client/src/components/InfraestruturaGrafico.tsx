import {
  PieChart,
  Pie,
  Cell,
  Legend,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

interface InfraestruturaGraficoProps {
  data: Array<{
    name: string;
    value: number;
  }>;
}

export function InfraestruturaGrafico({ data }: InfraestruturaGraficoProps) {
  const COLORS = ["#1e40af", "#93c5fd"];

  return (
    <div className="w-full h-full bg-white rounded-lg p-6 shadow-sm border border-gray-200">
      <div className="mb-6">
        <h3 className="text-xl font-bold text-gray-900 font-playfair">
          Proporção de Escolas com Infraestrutura Tecnológica
        </h3>
        <p className="text-sm text-gray-600 mt-1">
          Escolas públicas em Campinas com acesso a laboratório de informática e internet
        </p>
      </div>

      <ResponsiveContainer width="100%" height={400}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={80}
            outerRadius={140}
            paddingAngle={2}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip
            formatter={(value) => [`${value} escolas`, ""]}
            contentStyle={{
              backgroundColor: "#fff",
              border: "1px solid #e5e7eb",
              borderRadius: "0.5rem",
            }}
          />
          <Legend
            wrapperStyle={{ paddingTop: "1.5rem" }}
            verticalAlign="bottom"
            height={36}
          />
        </PieChart>
      </ResponsiveContainer>

      {/* Estatísticas */}
      <div className="mt-8 grid grid-cols-2 gap-4">
        {data.map((item, idx) => {
          const total = data.reduce((sum, d) => sum + d.value, 0);
          const percentage = ((item.value / total) * 100).toFixed(1);
          return (
            <div key={idx} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
              <p className="text-gray-600 text-sm font-medium">{item.name}</p>
              <p className="text-2xl font-bold text-gray-900 mt-2 font-playfair">
                {item.value}
              </p>
              <p className="text-gray-500 text-xs mt-1">{percentage}% das escolas</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
