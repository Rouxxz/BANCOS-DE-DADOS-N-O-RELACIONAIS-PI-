import { useMongoData } from "@/hooks/useMongoData";
import { DistribuicaoGrafico } from "@/components/DistribuicaoGrafico";
import { MediasPorDependenciaGrafico } from "@/components/MediasPorDependenciaGrafico";
import { InfraestruturaGrafico } from "@/components/InfraestruturaGrafico";
import { InfraVsNotasGrafico } from "@/components/InfraVsNotasGrafico";
import { Spinner } from "@/components/ui/spinner";

/**
 * Design Philosophy: Minimalismo Analítico
 * - Tipografia forte com Playfair Display para títulos
 * - Espaçamento generoso e grid rigoroso
 * - Cores neutras com acentos em azul profundo (#1e40af)
 * - Foco absoluto na legibilidade dos dados
 */

export default function Home() {
  const {
    distribuicao,
    mediasPorDependencia,
    infraestrutura,
    infraVsNotas,
    loading,
    error,
  } = useMongoData();

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <Spinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 font-semibold">Erro ao carregar dados</p>
          <p className="text-gray-600 text-sm mt-2">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-8 py-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 font-playfair">
              Dashboard ENEM Campinas
            </h1>
            <p className="text-gray-600 mt-2">
              Análise de desempenho educacional e infraestrutura tecnológica
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-8 py-12">
        {/* Seção de Contexto */}
        <section className="mb-16">
          <div className="grid grid-cols-3 gap-8 mb-12 items-start">
            {/* Card 1: Total de Registros */}
            <div className="bg-gray-50 rounded-lg p-6 border border-gray-200 text-center">
              <p className="text-gray-600 text-sm font-medium uppercase tracking-wide">
                Total de Alunos
              </p>
              <p className="text-4xl font-bold text-gray-900 mt-3 font-playfair">
                5.475
              </p>
              <p className="text-gray-500 text-xs mt-2">
                Dados do ENEM em Campinas
              </p>
            </div>

            {/* Card 2: Média Geral Matemática */}
            <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
              <p className="text-gray-600 text-sm font-medium uppercase tracking-wide">
                Média Matemática
              </p>
              <p className="text-4xl font-bold text-blue-700 mt-3 font-playfair">
                576.2
              </p>
              <p className="text-gray-500 text-xs mt-2">
                Escala de 0 a 1000
              </p>
            </div>

            {/* Card 3: Média Geral Redação */}
            <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
              <p className="text-gray-600 text-sm font-medium uppercase tracking-wide">
                Média Redação
              </p>
              <p className="text-4xl font-bold text-blue-700 mt-3 font-playfair">
                671.4
              </p>
              <p className="text-gray-500 text-xs mt-2">
                Escala de 0 a 1000
              </p>
            </div>
          </div>

          {/* Divisor */}
          <div className="h-px bg-gray-200 mb-12"></div>
        </section>

        {/* Gráficos */}
        <section className="space-y-12">
          {/* Gráfico 1: Distribuição */}
          <div>
            <DistribuicaoGrafico data={distribuicao} />
            <div className="mt-6 bg-gray-50 rounded-lg p-6 border border-gray-200">
              <h4 className="text-sm font-semibold text-gray-900 uppercase tracking-wide">
                Interpretação
              </h4>
              <p className="text-gray-700 text-sm mt-3 leading-relaxed">
                O gráfico acima demonstra a distribuição de notas em Matemática e Redação
                entre os alunos da rede pública de Campinas. Observa-se uma concentração
                significativa de alunos nas faixas de 400-600 pontos, indicando que a
                maioria dos estudantes apresenta desempenho médio a baixo-médio. Essa
                distribuição justifica a necessidade de intervenções pedagógicas focadas,
                como tutoria de IA para reforço em Matemática.
              </p>
            </div>
          </div>

          {/* Gráfico 2: Médias por Dependência */}
          <div>
            <MediasPorDependenciaGrafico data={mediasPorDependencia} />
            <div className="mt-6 bg-gray-50 rounded-lg p-6 border border-gray-200">
              <h4 className="text-sm font-semibold text-gray-900 uppercase tracking-wide">
                Interpretação
              </h4>
              <p className="text-gray-700 text-sm mt-3 leading-relaxed">
                A comparação entre dependências administrativas revela uma discrepância
                clara de desempenho. Escolas privadas apresentam médias significativamente
                superiores em todas as disciplinas, especialmente em Matemática e Redação.
                Escolas estaduais e municipais, que atendem a maior parte da população,
                demonstram desempenho inferior, evidenciando a necessidade de políticas
                educacionais que reduzam essa lacuna de qualidade.
              </p>
            </div>
          </div>

          {/* Gráfico 3: Infraestrutura */}
          <div>
            <InfraestruturaGrafico data={infraestrutura} />
            <div className="mt-6 bg-gray-50 rounded-lg p-6 border border-gray-200">
              <h4 className="text-sm font-semibold text-gray-900 uppercase tracking-wide">
                Interpretação
              </h4>
              <p className="text-gray-700 text-sm mt-3 leading-relaxed">
                A análise das escolas públicas de Campinas revela um cenário desafiador: apenas
                35% das instituições possuem laboratório de informática e acesso à internet de
                qualidade. Essa deficiência tecnológica representa um obstáculo significativo para
                a implementação de soluções digitais como tutoria de IA, evidenciando a necessidade
                de investimentos em infraestrutura tecnológica nas escolas públicas.
              </p>
            </div>
          </div>

          {/* Gráfico 4: Infraestrutura vs Notas */}
          <div>
            <InfraVsNotasGrafico data={infraVsNotas} />
          </div>
        </section>

        {/* Footer */}
        <footer className="mt-16 pt-8 border-t border-gray-200">
          <p className="text-gray-500 text-xs">
            Dados baseados em registros do ENEM. Análise realizada para fins acadêmicos.
          </p>
        </footer>
      </main>
    </div>
  );
}
